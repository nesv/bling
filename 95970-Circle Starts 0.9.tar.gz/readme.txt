Description:
Circle Starts (v0.9)
Author: Cyriaque 'Cisoun' Skrapits
Website and Gimp files: http://cisoun.serveftp.net/Portfolio/Graphisme/Icones/Circle Starts
Licence: Creative Commons BY-NC-SA


Created for:
Ubuntu Studio, Ubuntu, Fedora, Arch, Debian, Mandriva, SuSE, Red Hat, FreeBSD, Gentoo, Mint, Windows, Apple, Kubuntu, OpenSolaris


HOW TO INSTALL IT
-------------------------
First method:
1) Find the folder of the icon theme that you are using (/home/[you]/.icons/[theme]).
2) Just rename the file "start-here.png" in the folder "24x24"/"32x32"/"48x48" (better) to "start-here.png.backup".
3) Copy the matching picture of your distribution in this folder and rename it to "start-here.png".
4) Reload the icon theme in gnome-appearance-properties.
5) Set the height of the panel which is using the main menu at 24/32/48px.

Second method:
1) Launch "gconf-editor" and open this following path: "apps/panel/objects/object_X" where X is the number which has "menu-object" as value of "object_type" key.
2) Then, in "custom_icon" property, write the path of one of the icons.
3) Check also "use_custom_icon" property.



Changelog:
v0.9
----
Added Kubuntu
Added OpenSolaris (green, blue & gray)

v0.8
----
New style
(4.1.2009) Added new model

v0.7
----
Added FreeBSD icon
Added Gentoo icon
Added Mint icon
Added Windows icon
Added Apple icon
Corrected .xcf model (Gimp)

v0.6
----
Added Red Hat icon
Added SuSE icon

v0.5
----
Added 2 Debian icons
Added 2 Mandriva icons

v0.4
----
Added Arch icon

v0.3
----
Added Fedora Core icon

v0.2
----
Added Ubuntu icon

v0.1
----
First version
